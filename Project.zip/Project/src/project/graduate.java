/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

/**
 *
 * @author Byungkyu
 */
public abstract class graduate extends person {
    protected String speciality;
    protected String advisor;

    public graduate() {
    }
    

    public graduate(String speciality, String advisor, String userID, String Password, String PUID, String firstName, String middleName, String lastName, String address1, String address2, String city, String state, String country, String zipcode, String phone) {
        super(userID, Password, PUID, firstName, middleName, lastName, address1, address2, city, state, country, zipcode, phone);
        this.speciality = speciality;
        this.advisor = advisor;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    public String getAdvisor() {
        return advisor;
    }

    public void setAdvisor(String advisor) {
        this.advisor = advisor;
    }
    
    


}
