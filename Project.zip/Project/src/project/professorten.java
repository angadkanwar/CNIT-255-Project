/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

/**
 *
 * @author Byungkyu
 */
public class professorten extends professors{
    String tenureLenght;

    public professorten(String tenureLenght, String noClass, String department, String userID, String Password, String PUID, String firstName, String middleName, String lastName, String address1, String address2, String city, String state, String country, String zipcode, String phone) {
        super(noClass, department, userID, Password, PUID, firstName, middleName, lastName, address1, address2, city, state, country, zipcode, phone);
        this.tenureLenght = tenureLenght;
    }

    public String getTenureLenght() {
        return tenureLenght;
    }

    public void setTenureLenght(String tenureLenght) {
        this.tenureLenght = tenureLenght;
    }
    
    
}
