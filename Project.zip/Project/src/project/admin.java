/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

/**
 *
 * @author Byungkyu
 */
public class admin extends person {
    String department;
    String workLocation;
    String jobTitle;


    public admin(String department, String workLocation, String jobTitle, String userID, String Password, String PUID, String firstName, String middleName, String lastName, String address1, String address2, String city, String state, String country, String zipcode, String phone) {
        super(userID, Password, PUID, firstName, middleName, lastName, address1, address2, city, state, country, zipcode, phone);
        this.department = department;
        this.workLocation = workLocation;
        this.jobTitle = jobTitle;
    }
    
    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getWorkLocation() {
        return workLocation;
    }

    public void setWorkLocation(String workLocation) {
        this.workLocation = workLocation;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }
    
    
    
    
}
