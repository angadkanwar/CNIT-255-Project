/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

/**
 *
 * @author Byungkyu
 */
public class undergraduate extends person {
    
    private String major;
    private String creditHour;
    private String gpa;

    public undergraduate(String major, String creditHour, String gpa) {
        this.major = major;
        this.creditHour = creditHour;
        this.gpa = gpa;
    }

    public undergraduate(String major, String creditHour, String gpa, String userID, String Password, String PUID, String firstName, String middleName, String lastName, String address1, String address2, String city, String state, String country, String zipcode, String phone) {
        super(userID, Password, PUID, firstName, middleName, lastName, address1, address2, city, state, country, zipcode, phone);
        this.major = major;
        this.creditHour = creditHour;
        this.gpa = gpa;
    }
    

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getCreditHour() {
        return creditHour;
    }

    public void setCreditHour(String creditHour) {
        this.creditHour = creditHour;
    }

    public String getGpa() {
        return gpa;
    }

    public void setGpa(String gpa) {
        this.gpa = gpa;
    }
    
    
 
}
